/*:
 # Solar system simulator
 
 A solar system is composed by a star (like the Sun) and all the other objects travelling around it, such as planets, moons, comets, asteroids and meteoroids. Most stars host their own planets and there are likely tens of billions of other solar systems in Milky Way galaxy.
 
 Our solar system has 8 official planets: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus and Neptune. On this simulation, these planets had their orbits simplified to circumferences instead of ellipses, which might lead to some deviation of their real position.
 
 ### Instructions
 1. Change parameters below
 2. Tap on the screen if you want to freeze time
 */

import UIKit
import SpriteKit
import PlaygroundSupport

/*:
 On this simulation, you can adjust the screen width for a better experience.
 */
let width: CGFloat = 700

/*:
 Check how the planets were aligned on your birthday or other important dates!
 
 If you need some inspiration, you could check 06-05-2492, on this day the eight planets will be as close as they have ever been in the human history.
 
 The date must be in the following format: dd/mm/yyyy
 */
let date: String = "06-05-2492"

/*:
 Would you like to see planet orbits drawn?
 */
let showOrbits: Bool = false

/*:
 Here you can set the time speed per year.
 
 How fast you want it to be?
 
 By typing 2, every 2 seconds on the simulation will be equivalent to one year.
 */
let timeSpeed: Double = 10

/*:
You can't stop time in real life and probably you had already desired this. But luckily simulations exist, so we can do what is impossible in real life. This way you can stop time by tapping the screen or setting the following variable to false.
 
 */
let enableTime: Bool = false



Simulation.run(width: width, showOrbits: showOrbits, dateSelected: date, timeSpeed: timeSpeed, enablePlanetsOrbit: enableTime)


/*:
 
 ### Credits:
 [Solar System Exploration]: https://solarsystem.nasa.gov/solar-system/our-solar-system/overview/
 
 [Nasa JPL]: https://ssd.jpl.nasa.gov/horizons.cgi
 
 1. Solar system information retrieved on 30th March, 2018 from [Solar System Exploration].
 
 2. Planets position retrived on 28th March, 2018 from [Nasa JPL].
 */
