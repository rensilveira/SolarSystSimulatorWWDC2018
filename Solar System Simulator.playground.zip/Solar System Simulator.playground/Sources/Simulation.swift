//
//  Simulation.swift
//  Solar System Simulator
//
//  Created by Renan Silveira on 20/03/2018.
//  Copyright © 2018 Renan Silveira. All rights reserved.
//

import SpriteKit
import PlaygroundSupport

public class Simulation {
    
    // MARK: Runs solar system simulation
    public static func run(width frameWidth: CGFloat, showOrbits: Bool, dateSelected: String, timeSpeed: Double, enablePlanetsOrbit: Bool) {
        
        SetupParameters.shared.setupSimulation(showOrbits: showOrbits, dateSelected: dateSelected, timeSpeed: timeSpeed, enablePlanetsOrbit: enablePlanetsOrbit)
        
        let frameSize = CGSize(width: frameWidth * 0.75, height: frameWidth)
        let myFrame = CGRect(origin: CGPoint(), size: frameSize)
        let myView = SKView(frame: myFrame)
        let myScene = SolarSystemScene(size: myFrame.size)
        myScene.scaleMode = .aspectFit
        myScene.backgroundColor = SKColor.black
        myView.presentScene(myScene)
        myView.showsFPS = false
        myView.showsNodeCount = false
        
        PlaygroundPage.current.liveView = myView
    }
}
