//
//  SetupParameters.swift
//  Solar System Simulator
//
//  Created by Renan Silveira on 28/03/2018.
//  Copyright © 2018 Renan Silveira. All rights reserved.
//

import Foundation

public class SetupParameters {
    
    public static let shared = SetupParameters()
    
    public var showOrbits: Bool = Bool()
    public var dateSelected: String = String()
    public var timeSpeed: Double = Double()
    public var enablePlanetsOrbit: Bool = Bool()
    
    // MARK: Sets simulation variables
    public func setupSimulation(showOrbits: Bool, dateSelected: String, timeSpeed: Double, enablePlanetsOrbit: Bool) {
        self.showOrbits = showOrbits
        self.dateSelected = dateSelected
        self.timeSpeed = timeSpeed
        self.enablePlanetsOrbit = enablePlanetsOrbit
    }
}

