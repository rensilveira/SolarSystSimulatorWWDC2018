//
//  SolarSystemScene.swift
//  Solar System Simulator
//
//  Created by Renan Silveira on 20/03/2018.
//  Copyright © 2018 Renan Silveira. All rights reserved.
//

import SpriteKit
import GameplayKit

class SolarSystemScene: SKScene {
    
    var centerX: CGFloat = CGFloat()
    var centerY: CGFloat = CGFloat()
    var screenWidth: CGFloat = CGFloat()
    var screenHeight: CGFloat = CGFloat()
    
    var orbitRadiusMercury: CGFloat = CGFloat()
    var orbitRadiusVenus: CGFloat = CGFloat()
    var orbitRadiusEarth: CGFloat = CGFloat()
    var orbitRadiusMars: CGFloat = CGFloat()
    var orbitRadiusJupiter: CGFloat = CGFloat()
    var orbitRadiusSaturn: CGFloat = CGFloat()
    var orbitRadiusUranus: CGFloat = CGFloat()
    var orbitRadiusNeptune: CGFloat = CGFloat()
    
    var angularVelocityMercury: Double = (2 * Double.pi) / 87.97
    var angularVelocityVenus: Double = (2 * Double.pi) / 224.70
    var angularVelocityEarth: Double = (2 * Double.pi) / 365.26
    var angularVelocityMars: Double = (2 * Double.pi) / 686.98
    var angularVelocityJupiter: Double = (2 * Double.pi) / 4332.82
    var angularVelocitySaturn: Double = (2 * Double.pi) / 10755.70
    var angularVelocityUranus: Double = (2 * Double.pi) / 30687.15
    var angularVelocityNeptune: Double = (2 * Double.pi) / 60190.03
    
    var angularRefPositionMercury: Double = -0.992272112377191
    var angularRefPositionVenus: Double = 4.46267849137488
    var angularRefPositionEarth: Double = -0.950546840812075
    var angularRefPositionMars: Double = -0.904199474435431
    var angularRefPositionJupiter: Double = 4.05590158867123
    var angularRefPositionSaturn: Double = -1.55661288080359
    var angularRefPositionUranus: Double = 0.375270822855957
    var angularRefPositionNeptune: Double = -0.446358265642598
    
    var calendarDate: Int = Int()
    let currentCalendar = Calendar.current
    let dateFormatter: DateFormatter = DateFormatter()
    var differenceOfDaysFromRef: Double = Double()
    
    private var timeLabel: SKLabelNode = SKLabelNode()
    
    var venus: SKSpriteNode = SKSpriteNode()
    var mercury: SKSpriteNode = SKSpriteNode()
    var earth: SKSpriteNode = SKSpriteNode()
    var mars: SKSpriteNode = SKSpriteNode()
    var jupiter: SKSpriteNode = SKSpriteNode()
    var saturn: SKSpriteNode = SKSpriteNode()
    var uranus: SKSpriteNode = SKSpriteNode()
    var neptune: SKSpriteNode = SKSpriteNode()
    
    var helperNodeMercury: SKSpriteNode = SKSpriteNode()
    var helperNodeVenus: SKSpriteNode = SKSpriteNode()
    var helperNodeEarth: SKSpriteNode = SKSpriteNode()
    var helperNodeMars: SKSpriteNode = SKSpriteNode()
    var helperNodeJupiter: SKSpriteNode = SKSpriteNode()
    var helperNodeSaturn: SKSpriteNode = SKSpriteNode()
    var helperNodeUranus: SKSpriteNode = SKSpriteNode()
    var helperNodeNeptune: SKSpriteNode = SKSpriteNode()
    
    override func didMove(to view: SKView) {
        
        // Gets screen center
        centerX = view.center.x
        centerY = view.center.y
        
        // Gets screen size
        screenWidth = view.frame.width
        screenHeight = view.frame.height
        
        differenceOfDaysFromRef = calculateDifferenceOfDaysFromRef(date: SetupParameters.shared.dateSelected)
        
        calculatePlanetOrbits()
        
        initializeElements()
        
        createPlanets(animate: SetupParameters.shared.enablePlanetsOrbit)
        
        createOrbits(create: SetupParameters.shared.showOrbits)
        
        createDateCounter(timeSpeed: SetupParameters.shared.timeSpeed)
    }
    
    // MARK: Implements date counter based on the time speed set
    func createDateCounter(timeSpeed: Double) {
        // Used real Earth translation period of 365.26 to contabilize also leap years
        let delay = SKAction.wait(forDuration: TimeInterval(timeSpeed/365.26))
        let outputFormatter = DateFormatter()
        // Sets output date format
        outputFormatter.dateFormat = "dd-MMM-yyyy"
        // Sets initial date to date inserted by user
        var date = self.dateFormatter.date(from: SetupParameters.shared.dateSelected)
        if date != nil {
            self.timeLabel.text = outputFormatter.string(from: date!)
            // Increments date by 1 day
            let incrementScore = SKAction.run ({
                date = self.currentCalendar.date(byAdding: .day, value: 1, to: date!)
                self.timeLabel.text = outputFormatter.string(from: date!)
            })
            if SetupParameters.shared.enablePlanetsOrbit {
               // Increments date based on the timeSpeed selected by the user
                self.run(SKAction.repeatForever(SKAction.sequence([delay,incrementScore])))
            }
        } else {
            self.timeLabel.text = "Wrong date"
        }
        
    }
    
    // MARK: Creates planets to the scene
    func createPlanets(animate: Bool) {
        let earthTranslationPeriod = Double(SetupParameters.shared.timeSpeed)
        createPlanet(name: "Mercury", planetNode: &mercury, helperNode: &helperNodeMercury, translation: earthTranslationPeriod * 0.24, animate: animate)
        createPlanet(name: "Venus", planetNode: &venus, helperNode: &helperNodeVenus, translation: earthTranslationPeriod * 0.62, animate: animate)
        createPlanet(name: "Earth", planetNode: &earth, helperNode: &helperNodeEarth, translation: earthTranslationPeriod, animate: animate)
        createPlanet(name: "Mars", planetNode: &mars, helperNode: &helperNodeMars, translation: earthTranslationPeriod * 1.88, animate: animate)
        createPlanet(name: "Jupiter", planetNode: &jupiter, helperNode: &helperNodeJupiter, translation: earthTranslationPeriod * 11.86, animate: animate)
        createPlanet(name: "Saturn", planetNode: &saturn, helperNode: &helperNodeSaturn, translation: earthTranslationPeriod * 29.45, animate: animate)
        createPlanet(name: "Uranus", planetNode: &uranus, helperNode: &helperNodeUranus, translation: earthTranslationPeriod * 84.01, animate: animate)
        createPlanet(name: "Neptune", planetNode: &neptune, helperNode: &helperNodeNeptune, translation: earthTranslationPeriod * 164.79, animate: animate)
    }
    
    // MARK: Sets planet initial position according to its approximately position on inserted date
    func movePlanetToInitialPosition(planet: inout SKSpriteNode, orbitRadius: CGFloat, angularVelocity: Double, angularRefPosition: Double) {
        // Calculates the new angle after angular displacement
        let angle = (differenceOfDaysFromRef * angularVelocity + angularRefPosition).truncatingRemainder(dividingBy:  2 * Double.pi)
        // As the screen works based on the cartesian system, it gets x and y position using trigonometry
        let xPlanetPosition = centerX - screenWidth/2 + (orbitRadius * CGFloat((cos(angle))))
        let yPlanetPosition = centerY - screenHeight/2 + (orbitRadius * CGFloat((sin(angle))))
        planet.position = CGPoint(x: xPlanetPosition, y: yPlanetPosition)
    }
    
    // MARK: Initializes scene elements
    func initializeElements() {
        
        // Initializes time label
        timeLabel.fontName = "AvenirNext-Bold"
        timeLabel.fontSize = 24
//        timeLabel.position = CGPoint(x: centerX, y: centerY - screenHeight/2*0.68)
        timeLabel.position = CGPoint(x: centerX, y: centerY - screenHeight/2*0.85)
        self.addChild(timeLabel)
        
        // Initializes sun on the center of the solar system
        let sun: SKSpriteNode = SKSpriteNode(imageNamed: "Sun")
        sun.position = CGPoint(x: centerX, y: centerY)
        sun.zPosition = 2
        sun.setScale(0.3*screenWidth/810)
        self.addChild(sun)
        
        // Initializes sun shadow and enables the animation of 0.5 rotation per second
        let sunShadow: SKSpriteNode = SKSpriteNode(imageNamed: "SunShadow")
        sunShadow.position = CGPoint(x: centerX, y: centerY)
        sunShadow.zPosition = 3
        sunShadow.setScale(0.3*screenWidth/810)
        sunShadow.run(SKAction.repeatForever(SKAction.rotate(byAngle: 6, duration: 2)))
        self.addChild(sunShadow)
        
        // Set the background behind all nodes created
        let backGround: SKSpriteNode = SKSpriteNode(imageNamed: "Background")
        backGround.position = CGPoint(x: centerX, y: centerY)
        backGround.zPosition = -5
        backGround.size = CGSize(width: screenWidth, height: screenHeight)
        self.addChild(backGround)
        
        venus = SKSpriteNode(imageNamed: "Venus")
        movePlanetToInitialPosition(planet: &venus, orbitRadius: orbitRadiusVenus, angularVelocity: angularVelocityVenus, angularRefPosition: angularRefPositionVenus)
        
        mercury = SKSpriteNode(imageNamed: "Mercury")
        movePlanetToInitialPosition(planet: &mercury, orbitRadius: orbitRadiusMercury, angularVelocity: angularVelocityMercury, angularRefPosition: angularRefPositionMercury)
        
        earth = SKSpriteNode(imageNamed: "Earth")
        movePlanetToInitialPosition(planet: &earth, orbitRadius: orbitRadiusEarth, angularVelocity: angularVelocityEarth, angularRefPosition: angularRefPositionEarth)
        
        mars = SKSpriteNode(imageNamed: "Mars")
        movePlanetToInitialPosition(planet: &mars, orbitRadius: orbitRadiusMars, angularVelocity: angularVelocityMars, angularRefPosition: angularRefPositionMars)
        
        jupiter = SKSpriteNode(imageNamed: "Jupiter")
        movePlanetToInitialPosition(planet: &jupiter, orbitRadius: orbitRadiusJupiter, angularVelocity: angularVelocityJupiter, angularRefPosition: angularRefPositionJupiter)
        
        saturn = SKSpriteNode(imageNamed: "Saturn")
        movePlanetToInitialPosition(planet: &saturn, orbitRadius: orbitRadiusSaturn, angularVelocity: angularVelocitySaturn, angularRefPosition: angularRefPositionSaturn)
        
        uranus = SKSpriteNode(imageNamed: "Uranus")
        movePlanetToInitialPosition(planet: &uranus, orbitRadius: orbitRadiusUranus, angularVelocity: angularVelocityUranus, angularRefPosition: angularRefPositionUranus)
        
        neptune = SKSpriteNode(imageNamed: "Neptune")
        movePlanetToInitialPosition(planet: &neptune, orbitRadius: orbitRadiusNeptune, angularVelocity: angularVelocityNeptune, angularRefPosition: angularRefPositionNeptune)
    }
    
    // MARK: Calculates planet orbit radius
    func calculatePlanetOrbits() {
        orbitRadiusMercury = screenWidth * 0.055
        orbitRadiusVenus = screenWidth * 0.105
        orbitRadiusEarth = screenWidth * 0.14
        orbitRadiusMars = screenWidth * 0.205
        orbitRadiusJupiter = screenWidth * 0.255
        orbitRadiusSaturn = screenWidth * 0.310
        orbitRadiusUranus = screenWidth * 0.385
        orbitRadiusNeptune = screenWidth * 0.48
    }
    
    // MARK: Creates planet orbit drawing
    func createPlanetOrbit(shapeNode: inout SKShapeNode, radius: CGFloat) {
        shapeNode = SKShapeNode(circleOfRadius: radius )
        shapeNode.position = CGPoint(x: centerX, y: centerY)
        shapeNode.zPosition = 1
        shapeNode.strokeColor = SKColor(red: 1, green: 1, blue: 1, alpha: 0.68)
        self.addChild(shapeNode)
    }
    
    // MARK: Creates all planet orbits
    func createOrbits(create: Bool) {
        if create {
            var orbitMercury: SKShapeNode = SKShapeNode()
            createPlanetOrbit(shapeNode: &orbitMercury, radius: orbitRadiusMercury)
            
            var orbitVenus: SKShapeNode = SKShapeNode()
            createPlanetOrbit(shapeNode: &orbitVenus, radius: orbitRadiusVenus)
            
            var orbitEarth: SKShapeNode = SKShapeNode()
            createPlanetOrbit(shapeNode: &orbitEarth, radius: orbitRadiusEarth)
            
            var orbitMars: SKShapeNode = SKShapeNode()
            createPlanetOrbit(shapeNode: &orbitMars, radius: orbitRadiusMars)
            
            var orbitJupiter: SKShapeNode = SKShapeNode()
            createPlanetOrbit(shapeNode: &orbitJupiter, radius: orbitRadiusJupiter)
            
            var orbitSaturn: SKShapeNode = SKShapeNode()
            createPlanetOrbit(shapeNode: &orbitSaturn, radius: orbitRadiusSaturn)
            
            var orbitUranus: SKShapeNode = SKShapeNode()
            createPlanetOrbit(shapeNode: &orbitUranus, radius: orbitRadiusUranus)
            
            var orbitNeptune: SKShapeNode = SKShapeNode()
            createPlanetOrbit(shapeNode: &orbitNeptune, radius: orbitRadiusNeptune)
        }
    }
    
    // MARK: Creates planet node
    func createPlanet(name: String, planetNode: inout SKSpriteNode, helperNode: inout SKSpriteNode, translation: Double, animate: Bool) {
        
        planetNode.zPosition = 2
        planetNode.setScale(0.20*screenWidth/810)
        
        // Creates helper node for earch planet to enable orbiting animation with its period
        helperNode = SKSpriteNode(color: .white, size: CGSize(width: 1, height: 1))
        helperNode.position = CGPoint(x: centerX, y: centerY)
        helperNode.addChild(planetNode)
        
        // Allows planets to orbit only if user enables time on the simulation
        if animate {
            helperNode.run(SKAction.repeatForever(SKAction.rotate(byAngle: CGFloat(2*Double.pi), duration: translation)), withKey: name)
        }
        self.addChild(helperNode)
    }
    
    // MARK:  Calculates time difference from the reference date
    func calculateDifferenceOfDaysFromRef(date: String) -> Double {
        // Sets input date format
        dateFormatter.dateFormat = "dd-MM-yyyy"
        let dateFinal = dateFormatter.date(from: date)
        // This is the reference date got to calculate planets position based on Nasa JPL website
        let dateInitial = dateFormatter.date(from: "07-08-2018")
        
        let currentCalendar = Calendar.current
        guard let start = currentCalendar.ordinality(of: .day, in: .era, for: dateInitial!) else {
            return 0
        }
        
        // Check if date inserted by the user is in compliance
        if let finalDate = dateFinal {
            if let end = currentCalendar.ordinality(of: .day, in: .era, for: finalDate){
                // If the date is in compliance, returns time difference in days
                return Double(end - start)
            }
        } else {
            self.timeLabel.text = "Wrong date"
            SetupParameters.shared.enablePlanetsOrbit = false
        }
        return 0
    }
    
    func touchDown(atPoint pos : CGPoint) {
        self.view?.isPaused = true
    }
    
    func touchUp(atPoint pos : CGPoint) {
        self.view?.isPaused = false
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
}
